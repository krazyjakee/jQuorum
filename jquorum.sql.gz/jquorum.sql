-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 18, 2012 at 09:47 PM
-- Server version: 5.5.9
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jquorum`
--

-- --------------------------------------------------------

--
-- Table structure for table `boards`
--

CREATE TABLE `boards` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  `description` text NOT NULL,
  `parent` int(11) NOT NULL,
  `sortorder` int(4) NOT NULL,
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `threads` int(11) NOT NULL DEFAULT '0',
  `posts` int(11) NOT NULL DEFAULT '0',
  `views` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `boards`
--

INSERT INTO `boards` VALUES(1, 'News', '', 0, 0, 0, 0, 0, 0);
INSERT INTO `boards` VALUES(2, 'News', 'General news about the project and it\\''s dependancies.', 1, 0, 1, 0, 0, 0);
INSERT INTO `boards` VALUES(9, 'Announcements', 'The latest project announcements from our development team.', 1, 1, 1, 0, 0, 0);
INSERT INTO `boards` VALUES(10, 'General Chat', '', 0, 1, 0, 0, 0, 0);
INSERT INTO `boards` VALUES(11, 'jQuorum Chat', 'Talk generally about the project here.', 10, 1, 0, 0, 0, 0);
INSERT INTO `boards` VALUES(12, 'jQuery Chat', 'Talk about jQuery and it\\''s extensions.', 10, 2, 0, 0, 0, 0);
INSERT INTO `boards` VALUES(13, 'Server', '', 11, 1, 0, 0, 0, 0);
INSERT INTO `boards` VALUES(14, 'Client', '', 11, 2, 0, 0, 0, 0);
INSERT INTO `boards` VALUES(15, 'Off Topic', 'Talk about anything within reason.', 10, 3, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  `permissions` text NOT NULL,
  `color` varchar(6) NOT NULL,
  `icon` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` VALUES(1, 'Administrator', '{"admin":true,"read":true,"write":true}', 'ff0000', '');
INSERT INTO `groups` VALUES(2, 'Registered', '{"admin":false,"read":true,"write":true}', 'dddddd', '');
INSERT INTO `groups` VALUES(3, 'Guest', '{"admin":false,"read":true,"write":false}', '777777', '');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastedited` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `title` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `author` varchar(25) NOT NULL,
  `board` int(11) NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `attribute` varchar(10) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `replies` int(11) NOT NULL DEFAULT '0',
  `views` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `posts`
--


-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting` varchar(250) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` VALUES(2, 'url', 'http://localhost/');
INSERT INTO `settings` VALUES(3, 'title', 'jQuorum');
INSERT INTO `settings` VALUES(4, 'keywords', '');
INSERT INTO `settings` VALUES(5, 'description', '');
INSERT INTO `settings` VALUES(6, 'bodycss', 'background-color:white; background-image:url(/img/bg.png); color:black;');
INSERT INTO `settings` VALUES(7, 'style', 'pepper-grinder');
INSERT INTO `settings` VALUES(8, 'domain', 'localhost');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(50) NOT NULL,
  `referrer` varchar(25) NOT NULL,
  `lastlogin` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `regdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ssid` varchar(200) NOT NULL,
  `group` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `users`
--

